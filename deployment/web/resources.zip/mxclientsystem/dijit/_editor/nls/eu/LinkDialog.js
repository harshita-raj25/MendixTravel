//>>built
define("dijit/_editor/nls/eu/LinkDialog",{createLinkTitle:"Estekaren propietateak",insertImageTitle:"Irudiaren propietateak",url:"URLa:",text:"Azalpena:",target:"Helburua:",set:"Ezarri",currentWindow:"Uneko leihoa",parentWindow:"Leiho gurasoa",topWindow:"Goi-goiko leihoa",newWindow:"Leiho berria"});
