//>>built
define("dijit/nls/al/loading",{loadingState:"Duke u ngarkuar",errorState:"Një gabim ndodhi"});
