//>>built
define("dijit/form/nls/ar/Textarea",({iframeEditTitle:"مساحة التحرير",iframeFocusTitle:"اطار مساحة التحرير"}));
